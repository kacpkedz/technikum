package com.example.imageview;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView myImageView;
    private Button selectImageButton;
    private Button resetButton;
    private Button filterButton;
    private Button unfilterButton;
    private Button zoomInButton;
    private Button zoomOutButton;

    private float skala = 1.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myImageView = findViewById(R.id.myImageView);
        selectImageButton = findViewById(R.id.selectImageButton);
        resetButton = findViewById(R.id.resetButton);
        filterButton = findViewById(R.id.filterButton);
        unfilterButton = findViewById(R.id.unfilterButton);
        zoomInButton = findViewById(R.id.zoomInButton);
        zoomOutButton = findViewById(R.id.zoomOutButton);

        ActivityResultLauncher<Intent> pickImageLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null && data.getData() != null) {
                            Uri imageUrl = data.getData();
                            try {
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUrl);
                                myImageView.setImageBitmap(bitmap);
                                resetScale();
                            } catch (Exception e) {
                                Toast.makeText(this, "Wystąpił błąd podczas ładowania zdjęcia", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
        );

        selectImageButton.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            pickImageLauncher.launch(intent);
        });

        resetButton.setOnClickListener(view -> {
            myImageView.setImageBitmap(null);
            resetScale();
        });

        filterButton.setOnClickListener(view -> {
            myImageView.setColorFilter(Color.argb(150, 0, 0, 0));
        });

        unfilterButton.setOnClickListener(view -> {
            myImageView.clearColorFilter();
        });

        zoomInButton.setOnClickListener(v -> {
            skala *= 1.1f;
            myImageView.setScaleX(skala);
            myImageView.setScaleY(skala);
        });

        zoomOutButton.setOnClickListener(v -> {
            skala *= 0.9f;
            myImageView.setScaleX(skala);
            myImageView.setScaleY(skala);
        });
    }

    private void resetScale() {
        skala = 1.0f;
        myImageView.setScaleX(skala);
        myImageView.setScaleY(skala);
    }
}