package com.example.odp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        EditText imie = findViewById(R.id.txtImie);
        EditText mail = findViewById(R.id.txtEmail);
        Button przeslij = findViewById(R.id.btnWyslij);

        przeslij.setOnClickListener(v -> {
            String name = imie.getText().toString();
            String email = mail.getText().toString();

            Intent intent = new Intent(MainActivity.this, AktywnoscPrzeslano.class);
            intent.putExtra("imie", name);
            intent.putExtra("email", email);
            startActivity(intent);
        });
    }
}