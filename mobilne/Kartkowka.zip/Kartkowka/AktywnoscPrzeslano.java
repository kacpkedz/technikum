package com.example.odp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AktywnoscPrzeslano extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_aktywnosc_przeslano);

        TextView textViewDane = findViewById(R.id.textViewDane);

        String name = getIntent().getStringExtra("imie");
        String email = getIntent().getStringExtra("email");

        textViewDane.setText("Email: " + email + ", imię: " + name);
    }
}